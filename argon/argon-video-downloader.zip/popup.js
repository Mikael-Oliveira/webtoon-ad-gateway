/** popup.js — Interface Argon. Toda regra (carteira, chave, download) vive no background; aqui só mostra e pede. */
const C = self.ARGON_CORE;
const STATUS_KEY = 'argonStatus';
const $ = (id) => document.getElementById(id);
const send = (msg) => chrome.runtime.sendMessage(msg);

let wallet = { credits: 0, lifetime: false };
let video = null; // { id, kind } quando a aba é YouTube
let tabId = null;
let media = [];   // vídeos achados em qualquer outro site
let showOthers = false; // lista completa só quando a pessoa pede
let mode = 'video';
let pollTimer = null;

/* ---------------------------------------------------------------- abas */
document.querySelectorAll('.tab').forEach((btn) =>
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((b) => b.classList.toggle('active', b === btn));
    $('tab-baixar').hidden = btn.dataset.tab !== 'baixar';
    $('tab-vitalicio').hidden = btn.dataset.tab !== 'vitalicio';
  })
);

/** Acabou o grátis do dia: leva para a aba 💎 Vitalício. */
function openLifetimeTab() {
  document.querySelector('.tab[data-tab="vitalicio"]').click();
}

/* ------------------------------------------------------------ render */
function renderWallet() {
  const el = $('credits');
  el.textContent = C.walletText(wallet);
  el.classList.toggle('life', wallet.lifetime);
  $('rule').textContent = wallet.lifetime ? 'Downloads ilimitados' : wallet.adEnabled ? '1 anúncio = 3 downloads' : 'Ilimitado: 💎 Vitalício R$ 15';
  $('cta').textContent = C.walletLabel(wallet);
  $('cta').disabled = !video && C.canUse(wallet);
  $('removeKey').hidden = !wallet.lifetime;
  renderMedia();
  if (wallet.lifetime) {
    $('keyMsg').className = 'msg ok';
    $('keyMsg').textContent = `✔ Vitalício ativo (${wallet.keyMasked})`;
  }
}

function renderStatus(s) {
  if (!s) return;
  $('status').dataset.state = s.state || 'idle';
  $('statusText').textContent = s.message || '';
  $('folder').textContent = s.folder ? `📁 ${s.folder}` : '';
  if (s.state === 'downloading' && s.downloadId != null) startPolling(s.downloadId);
  else {
    stopPolling();
    if (s.state === 'running' && s.progress?.total) {
      $('bar').style.display = 'block';
      $('barFill').style.width = `${Math.round((s.progress.done / s.progress.total) * 100)}%`;
    }
  }
}

/* ------------------------------------------------- qualquer site: lista de vídeos */
const ICON = { video: '🎬', audio: '🎧', hls: '📡', dash: '📡' };

function renderMedia() {
  const list = $('mediaList');
  if (!list || video) return;
  list.textContent = '';
  const can = C.canUse(wallet);
  const cur = media.find((m) => m.current);
  const others = media.filter((m) => m !== cur);
  const shown = cur && !showOthers ? [cur] : media;
  const more = $('showOthers');
  more.hidden = !cur || !others.length;
  more.textContent = showOthers ? '▲ Mostrar só este vídeo' : `▼ Outros vídeos da página (${others.length})`;
  for (const m of shown) {
    const row = document.createElement('div');
    row.className = 'media' + (m.current ? ' current' : '');
    const ico = document.createElement('span');
    ico.className = 'ico';
    ico.textContent = ICON[m.kind] || '🎬';
    const info = document.createElement('div');
    info.className = 'info';
    if (m.current) {
      const tag = document.createElement('div');
      tag.className = 'tag';
      tag.textContent = '▶ Vídeo da tela';
      info.append(tag);
    }
    const lbl = document.createElement('div');
    lbl.className = 'lbl';
    lbl.textContent = m.label;
    const host = document.createElement('div');
    host.className = 'host';
    host.textContent = m.host;
    info.append(lbl, host);
    const go = document.createElement('button');
    go.className = 'go';
    const blocked = /protegido|ao vivo/.test(m.label) || m.kind === 'dash';
    go.disabled = blocked;
    go.textContent = blocked ? 'Indisponível' : can ? '⚡ Baixar' : wallet.adEnabled ? '▶ Anúncio +3' : '💎 Vitalício';
    go.title = blocked ? 'Conteúdo protegido, ao vivo ou em formato não suportado' : '';
    go.addEventListener('click', () => downloadItem(m, go));
    row.append(ico, info, go);
    list.append(row);
  }
}

async function downloadItem(m, btn) {
  btn.disabled = true;
  const can = C.canUse(wallet);
  if (!can && !wallet.adEnabled) {
    btn.disabled = false;
    return openLifetimeTab();
  }
  const res = await send(can ? { type: 'DOWNLOAD_MEDIA', tabId, itemId: m.id } : { type: 'REQUEST_AD', tabId, itemId: m.id });
  btn.disabled = false;
  if (res?.code === 'NEED_AD') return refresh();
  if (!res?.ok) renderStatus({ state: 'error', message: res?.message || 'Não foi possível iniciar.' });
}

async function scanMedia() {
  $('mediaNote').hidden = false;
  $('mediaNote').textContent = 'Procurando vídeos nesta página...';
  const res = await send({ type: 'GET_PAGE_MEDIA', tabId });
  media = res?.items || [];
  $('pageTitle').textContent = res?.title || '';
  $('mediaNote').hidden = !!media.length;
  $('mediaNote').textContent = res?.note || (res?.ok ? '' : res?.message || 'Não consegui ler esta página.');
  renderMedia();
}
$('rescan').addEventListener('click', scanMedia);
$('reloadExt')?.addEventListener('click', () => {
  const btn = $('reloadExt');
  btn.disabled = true;
  btn.textContent = '↻ Atualizando...';
  try { chrome.runtime.requestUpdateCheck?.(() => {}); } catch (_) {}
  setTimeout(() => chrome.runtime.reload(), 120);
});
$('showOthers').addEventListener('click', () => {
  showOthers = !showOthers;
  renderMedia();
});

function startPolling(id) {
  stopPolling();
  const tick = async () => {
    const [d] = await chrome.downloads.search({ id });
    if (!d) return stopPolling();
    const bar = $('bar');
    if (d.totalBytes > 0 && d.state === 'in_progress') {
      bar.style.display = 'block';
      $('barFill').style.width = `${Math.round((d.bytesReceived / d.totalBytes) * 100)}%`;
    } else {
      bar.style.display = 'none';
    }
  };
  tick();
  pollTimer = setInterval(tick, 500);
}
function stopPolling() {
  clearInterval(pollTimer);
  pollTimer = null;
  $('bar').style.display = 'none';
}

function setMode(m) {
  mode = m;
  $('modeVideo').classList.toggle('active', m === 'video');
  $('modeAudio').classList.toggle('active', m === 'audio');
}
$('modeVideo').addEventListener('click', () => setMode('video'));
$('modeAudio').addEventListener('click', () => setMode('audio'));

/* ------------------------------------------------------------- ações */
$('cta').addEventListener('click', async () => {
  const need = !C.canUse(wallet);
  if (need && !wallet.adEnabled) return openLifetimeTab();
  if (!video && !need) return;
  $('cta').disabled = true;
  const res = need
    ? await send({ type: 'REQUEST_AD', videoId: video?.id || null, mode })
    : await send({ type: 'DOWNLOAD', videoId: video.id, mode });
  $('cta').disabled = false;

  if (res?.code === 'NEED_AD') {
    await refresh();
    return;
  }
  if (!res?.ok) renderStatus({ state: 'error', message: res?.message || 'Não foi possível iniciar.' });
  // mode 'ad': a aba do anúncio abre e o popup fecha com a troca de aba.
});

$('buy').addEventListener('click', () => send({ type: 'OPEN_CHECKOUT' }));

$('activate').addEventListener('click', async () => {
  const res = await send({ type: 'ACTIVATE_KEY', key: $('key').value });
  if (res?.ok) {
    wallet = res;
    $('key').value = '';
    renderWallet();
  } else {
    $('keyMsg').className = 'msg bad';
    $('keyMsg').textContent = res?.message || 'Chave inválida.';
  }
});
$('key').addEventListener('keydown', (e) => e.key === 'Enter' && $('activate').click());

$('removeKey').addEventListener('click', async () => {
  const res = await send({ type: 'CLEAR_KEY' });
  if (res?.ok) wallet = res;
  $('keyMsg').className = 'msg';
  $('keyMsg').textContent = '';
  renderWallet();
});

/* -------------------------------------------------------------- init */
async function refresh() {
  const res = await send({ type: 'GET_WALLET' });
  if (res?.ok) wallet = res;
  renderWallet();
}

async function init() {
  await refresh();
  const st = await send({ type: 'GET_STATUS' });
  if (st?.ok) renderStatus(st.status);

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  tabId = tab?.id ?? null;
  // edição da loja: no YouTube não existe o modo YouTube (a lista mostra o aviso do background)
  video = (self.ARGON_CONFIG || {}).edition === 'store' ? null : C.parseVideo(tab?.url);
  $('videoBox').hidden = !video;
  $('seg').hidden = !video;
  $('cta').hidden = !video && C.canUse(wallet);
  $('mediaBox').hidden = !!video;
  if (!video && tabId != null) scanMedia();
  if (video) {
    $('vtitle').textContent = (tab.title || '').replace(/ - YouTube$/, '') || video.id;
    $('vid').textContent = `${video.kind === 'shorts' ? 'Short' : 'Vídeo'} · ${video.id}`;
    $('thumb').src = `https://i.ytimg.com/vi/${video.id}/mqdefault.jpg`;
  }
  renderWallet();
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes[STATUS_KEY]) renderStatus(changes[STATUS_KEY].newValue);
  if (changes.argonCredits || changes.argonKey) refresh();
});

init();
