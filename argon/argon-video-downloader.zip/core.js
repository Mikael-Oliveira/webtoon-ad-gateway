/**
 * core.js — Lógica pura do Argon Video Downloader (sem chrome.*), usada no background, nas páginas da extensão
 * e nos testes (Node: require). Chave vitalícia, carteira/limite diário, detecção de mídia, HLS, nomes de arquivo.
 * O extrator do YouTube fica num arquivo separado (só na edição PRO).
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.ARGON_CORE = api;
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ================================================================ chave vitalícia */

  const ALPHABET = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const KEY_RE = /^ARGON-([A-Z0-9]{4})-([A-Z0-9]{4})-([A-Z0-9])$/;

  /**
   * Dígito verificador do corpo (8 caracteres). Pondera pela posição e mistura com um sal,
   * então trocar duas letras de lugar muda o dígito. AVISO: validação 100% local é burlável
   * por quem lê o código; para cobrar de verdade use um servidor (ver LEIA-ME).
   */
  function checkDigit(body) {
    let s = 7;
    for (let i = 0; i < body.length; i++) s = (s * 31 + body.charCodeAt(i) * (i + 3)) % 1000003;
    return ALPHABET[s % 36];
  }

  function validateKey(key) {
    const m = KEY_RE.exec(String(key || '').trim().toUpperCase());
    return !!m && checkDigit(m[1] + m[2]) === m[3];
  }

  /** Gera uma chave válida a partir de 8 caracteres (A-Z0-9). */
  function makeKey(body8) {
    const b = String(body8).toUpperCase();
    if (!/^[A-Z0-9]{8}$/.test(b)) throw new Error('O corpo da chave precisa ter 8 caracteres A-Z/0-9.');
    return `ARGON-${b.slice(0, 4)}-${b.slice(4)}-${checkDigit(b)}`;
  }

  function maskKey(key) {
    return key ? key.slice(0, 6) + '••••-••••-' + key.slice(-1) : '';
  }

  /* ===================================================================== carteira */

  const AD_REWARD = 3; // 1 anúncio = 3 downloads

  const walletGrant = (credits) => (Number(credits) || 0) + AD_REWARD;
  const walletConsume = (credits) => Math.max(0, (Number(credits) || 0) - 1);
  const canDownload = (credits, lifetime) => !!lifetime || (Number(credits) || 0) > 0;

  /** Texto do botão principal (popup e botão do YouTube usam o mesmo). */
  function ctaLabel(credits, lifetime) {
    if (lifetime) return '⚡ Baixar Agora (Vitalício ∞)';
    if (credits > 0) return `⚡ Baixar Agora (Restam ${credits} de ${AD_REWARD} créditos)`;
    return `⚡ Liberar +${AD_REWARD} Downloads (Ver 1 Anúncio)`;
  }

  const creditsText = (credits, lifetime) => (lifetime ? '∞ (Vitalício Ativo)' : `${credits} de ${AD_REWARD}`);

  /* ---------- plano grátis diário (w = { lifetime, freeLeft, freePerDay, credits, adEnabled }) ---------- */

  /** 'AAAA-MM-DD' no fuso do computador (tzOffsetMin = new Date().getTimezoneOffset()). */
  function dayKey(ms, tzOffsetMin = 0) {
    return new Date(ms - tzOffsetMin * 60000).toISOString().slice(0, 10);
  }

  /** Quantos downloads grátis ainda restam hoje. daily = { day, used }. */
  function freeLeft(daily, today, perDay) {
    const used = daily && daily.day === today ? Number(daily.used) || 0 : 0;
    return Math.max(0, perDay - used);
  }

  const canUse = (w) => !!w.lifetime || w.freeLeft > 0 || (!!w.adEnabled && w.credits > 0);

  function walletLabel(w) {
    if (w.lifetime) return '⚡ Baixar Agora (Vitalício ∞)';
    if (w.freeLeft > 0) return `⚡ Baixar Agora (${w.freeLeft} de ${w.freePerDay} grátis hoje)`;
    if (w.adEnabled && w.credits > 0) return ctaLabel(w.credits, false);
    if (w.adEnabled) return ctaLabel(0, false);
    return '💎 Limite de hoje atingido · Vitalício R$ 15';
  }

  function walletText(w) {
    if (w.lifetime) return '∞ (Vitalício Ativo)';
    const extra = w.adEnabled && w.credits > 0 ? ` + ${w.credits} crédito(s)` : '';
    return `${w.freeLeft} de ${w.freePerDay} hoje${extra}`;
  }

  /* ================================================== links do YouTube (detectar a aba) */

  const ID_RE = /^[A-Za-z0-9_-]{11}$/;

  /** Aceita watch?v=, /shorts/, /live/, /embed/ e youtu.be. Devolve { id, kind } ou null. */
  function parseVideo(rawUrl) {
    let u;
    try {
      u = new URL(String(rawUrl || ''));
    } catch (_) {
      return null;
    }
    const host = u.hostname.replace(/^(www|m|music)\./, '');
    let id = null;
    let kind = 'watch';
    if (host === 'youtu.be') {
      id = u.pathname.slice(1).split('/')[0];
    } else if (host === 'youtube.com') {
      const m = /^\/(shorts|live|embed)\/([^/?#]+)/.exec(u.pathname);
      if (m) {
        kind = m[1] === 'shorts' ? 'shorts' : 'watch';
        id = m[2];
      } else if (u.pathname === '/watch') {
        id = u.searchParams.get('v');
      }
    }
    return id && ID_RE.test(id) ? { id, kind } : null;
  }

  /* ================================================================== arquivos */

  function safeName(value, fallback) {
    let name = String(value || '')
      .normalize('NFKC')
      .replace(/[\\/:*?"<>|\u0000-\u001f]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .replace(/^[. ]+|[. ]+$/g, '')
      .slice(0, 90)
      .trim();
    if (!name || /^(con|prn|aux|nul|com\d|lpt\d)$/i.test(name)) name = fallback;
    return name;
  }

  /** Pasta relativa a Downloads: Argon/Videos/<título> [id].mp4 ou Argon/Audios/<título> [id].m4a */
  function fileName(info, rootFolder = 'Argon') {
    const folder = info.mode === 'audio' ? 'Audios' : 'Videos';
    return `${rootFolder}/${folder}/${safeName(info.title, 'video')} [${info.videoId}].${info.ext}`;
  }

  /* ============================================== modo universal (qualquer site) */

  const VIDEO_EXT = ['mp4', 'webm', 'm4v', 'mov', 'mkv', 'flv', 'ogv', '3gp'];
  const AUDIO_EXT = ['mp3', 'm4a', 'aac', 'ogg', 'oga', 'opus', 'wav', 'flac'];
  const SEGMENT_EXT = ['ts', 'm4s', 'm4f', 'cmfv', 'cmfa', 'key'];
  const CT_EXT = {
    'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov', 'video/x-matroska': 'mkv', 'video/x-flv': 'flv',
    'video/ogg': 'ogv', 'video/3gpp': '3gp', 'audio/mpeg': 'mp3', 'audio/mp4': 'm4a', 'audio/aac': 'aac', 'audio/ogg': 'ogg',
    'audio/opus': 'opus', 'audio/wav': 'wav', 'audio/x-wav': 'wav', 'audio/flac': 'flac', 'audio/webm': 'webm'
  };
  /** Hosts com extrator próprio (o vídeo de lá não passa pelo modo universal). */
  const SPECIAL_HOSTS = /(^|\.)(googlevideo\.com|youtube\.com|ytimg\.com)$/;

  /**
   * Classifica uma URL/Content-Type como mídia baixável.
   * → { kind: 'video'|'audio'|'hls'|'dash', ext } ou null (página, imagem, segmento de stream, YouTube).
   */
  function classifyMedia(url, contentType) {
    let u;
    try { u = new URL(url); } catch (_) { return null; }
    if (!/^https?:$/.test(u.protocol) || SPECIAL_HOSTS.test(u.hostname)) return null;
    const ct = String(contentType || '').toLowerCase().split(';')[0].trim();
    const ext = (/\.([a-z0-9]{2,5})$/i.exec(u.pathname) || [])[1]?.toLowerCase() || '';
    if (ct === 'video/mp2t' || ct === 'video/iso.segment' || SEGMENT_EXT.includes(ext)) return null;
    if (/mpegurl/.test(ct) || ext === 'm3u8') return { kind: 'hls', ext: 'm3u8' };
    if (ct === 'application/dash+xml' || ext === 'mpd') return { kind: 'dash', ext: 'mpd' };
    if (ct.startsWith('video/') || VIDEO_EXT.includes(ext)) return { kind: 'video', ext: VIDEO_EXT.includes(ext) ? ext : ext === 'ogg' ? 'ogg' : CT_EXT[ct] || 'mp4' };
    if (ct.startsWith('audio/') || AUDIO_EXT.includes(ext)) return { kind: 'audio', ext: AUDIO_EXT.includes(ext) ? ext : CT_EXT[ct] || 'mp3' };
    return null;
  }

  /** Chave de deduplicação: o mesmo arquivo pedido em pedaços (Range/params de byte) conta uma vez só. */
  function mediaKey(url) {
    try {
      const u = new URL(url);
      for (const p of ['range', 'bytestart', 'byteend', 'start', 'end', 'rn', 'rbuf']) u.searchParams.delete(p);
      u.hash = '';
      return u.href;
    } catch (_) {
      return url;
    }
  }

  function m3u8Attrs(s) {
    const o = {};
    const re = /([A-Z0-9-]+)=("[^"]*"|[^,]*)/g;
    let m;
    while ((m = re.exec(s))) o[m[1]] = m[2].replace(/^"|"$/g, '');
    return o;
  }

  /**
   * Lê uma playlist HLS. Master → { type:'master', variants, media }. Mídia → { type:'media', segments, init,
   * encrypted, byterange, ended, duration, ext }. Texto que não é M3U8 → null.
   */
  function parseM3U8(text, baseUrl) {
    const lines = String(text || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    if (!lines.length || !lines[0].startsWith('#EXTM3U')) return null;
    const abs = (x) => new URL(x, baseUrl).href;

    if (lines.some((l) => l.startsWith('#EXT-X-STREAM-INF'))) {
      const media = lines.filter((l) => l.startsWith('#EXT-X-MEDIA:')).map((l) => {
        const a = m3u8Attrs(l.slice(13));
        return { type: a.TYPE, group: a['GROUP-ID'], name: a.NAME || '', url: a.URI ? abs(a.URI) : null, isDefault: a.DEFAULT === 'YES' };
      });
      const variants = [];
      for (let i = 0; i < lines.length; i++) {
        if (!lines[i].startsWith('#EXT-X-STREAM-INF:')) continue;
        const a = m3u8Attrs(lines[i].slice(18));
        const uri = lines.slice(i + 1).find((l) => !l.startsWith('#'));
        if (!uri) continue;
        const height = Number((/x(\d+)/.exec(a.RESOLUTION || '') || [])[1]) || 0;
        variants.push({ url: abs(uri), bandwidth: Number(a.BANDWIDTH) || 0, height, audioGroup: a.AUDIO || null, codecs: a.CODECS || '' });
      }
      return { type: 'master', variants, media };
    }

    const out = { type: 'media', segments: [], init: null, encrypted: false, byterange: false, ended: false, duration: 0, ext: 'ts' };
    for (const l of lines) {
      if (l.startsWith('#EXT-X-KEY:')) {
        const method = m3u8Attrs(l.slice(11)).METHOD;
        if (method && method !== 'NONE') out.encrypted = true;
      } else if (l.startsWith('#EXT-X-MAP:')) {
        const a = m3u8Attrs(l.slice(11));
        if (a.URI) out.init = abs(a.URI);
        if (a.BYTERANGE) out.byterange = true;
      } else if (l.startsWith('#EXT-X-BYTERANGE')) {
        out.byterange = true;
      } else if (l.startsWith('#EXTINF:')) {
        out.duration += parseFloat(l.slice(8)) || 0;
      } else if (l === '#EXT-X-ENDLIST') {
        out.ended = true;
      } else if (!l.startsWith('#')) {
        out.segments.push(abs(l));
      }
    }
    const first = out.segments[0] || '';
    if (out.init || /\.(m4s|mp4|m4v|cmfv)(\?|$)/i.test(first)) out.ext = 'mp4';
    return out;
  }

  /**
   * Escolhe a melhor variante: prefere as que já têm o áudio junto (sem grupo de áudio separado com URI),
   * e entre elas a de maior BANDWIDTH. Devolve { variant, audio } (audio = faixa separada, se precisar).
   */
  function pickVariant(master) {
    const sepAudio = (v) => v.audioGroup && master.media.some((m) => m.type === 'AUDIO' && m.group === v.audioGroup && m.url);
    const byBw = (a, b) => b.bandwidth - a.bandwidth;
    const muxed = master.variants.filter((v) => !sepAudio(v)).sort(byBw);
    if (muxed.length) return { variant: muxed[0], audio: null };
    const v = [...master.variants].sort(byBw)[0];
    if (!v) return null;
    const group = master.media.filter((m) => m.type === 'AUDIO' && m.group === v.audioGroup && m.url);
    return { variant: v, audio: group.find((m) => m.isDefault) || group[0] || null };
  }

  /** Baixa várias URLs em paralelo, na ordem, com novas tentativas. fetchFn(url) → Promise<ArrayBuffer>. */
  async function fetchAll(urls, fetchFn, { concurrency = 6, retries = 2, onProgress, isCancelled } = {}) {
    const out = new Array(urls.length);
    let next = 0;
    let done = 0;
    const worker = async () => {
      while (next < urls.length) {
        if (isCancelled?.()) throw new Error('Cancelado.');
        const i = next++;
        let lastErr;
        for (let t = 0; t <= retries; t++) {
          try {
            out[i] = await fetchFn(urls[i]);
            lastErr = null;
            break;
          } catch (err) {
            lastErr = err;
            await new Promise((r) => setTimeout(r, 400 * (t + 1)));
          }
        }
        if (lastErr) throw new Error(`Falhou a parte ${i + 1}/${urls.length}: ${lastErr.message || lastErr}`);
        done++;
        onProgress?.(done, urls.length);
      }
    };
    await Promise.all(Array.from({ length: Math.min(concurrency, urls.length) }, worker));
    return out;
  }

  /**
   * Duração (s) de um MP4 lendo o box 'mvhd' nos primeiros bytes (MP4 "faststart", como TikTok/Instagram/X).
   * Serve para achar QUAL arquivo é o vídeo que está na tela quando o player usa blob: (MSE). null se não achar.
   */
  function mp4Duration(bytes) {
    const b = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes || []);
    for (let i = 4; i < b.length - 32; i++) {
      if (b[i] !== 0x6d || b[i + 1] !== 0x76 || b[i + 2] !== 0x68 || b[i + 3] !== 0x64) continue; // 'mvhd'
      const dv = new DataView(b.buffer, b.byteOffset, b.byteLength);
      const p = i + 4;
      const v = b[p];
      const scale = v === 1 ? dv.getUint32(p + 20) : dv.getUint32(p + 12);
      const dur = v === 1 ? Number(dv.getBigUint64(p + 24)) : dv.getUint32(p + 16);
      return scale ? dur / scale : null;
    }
    return null;
  }

  /** Escolhe, entre candidatos com duração, o mais próximo da duração da tela (folga: 1 s ou 1,5%). */
  function matchDuration(target, candidates) {
    if (!target) return null;
    const tol = Math.max(1, target * 0.015);
    const ok = candidates.filter((c) => c.duration && Math.abs(c.duration - target) <= tol);
    return ok.sort((a, b) => Math.abs(a.duration - target) - Math.abs(b.duration - target) || (b.size || 0) - (a.size || 0))[0] || null;
  }

  /**
   * CDNs com proteção de hotlinking: só entregam o vídeo com a sessão do site (cookies + Referer/Origin exatos).
   * TikTok (*.tiktok.com, *.tiktokcdn.com), Instagram (*.cdninstagram.com), Facebook (*.fbcdn.net) e X (video.twimg.com).
   * Nesses, o download NÃO vai para o chrome.downloads direto: a extensão busca o arquivo (fetch na sessão,
   * no Offscreen Document), vira Blob e só então o blob: URL vai para o chrome.downloads.
   */
  const SESSION_HOST_RE = /^https?:\/\/[a-z0-9.-]*(tiktok|instagram|facebook|fbcdn|twimg|twitter)[a-z0-9.-]*(:\d+)?\//i;
  /** Só TikTok: Referer/Origin fixos em https://www.tiktok.com (regra DNR sempre ligada). */
  const TIKTOK_HOST_RE = /^https?:\/\/[a-z0-9.-]*tiktok[a-z0-9.-]*(:\d+)?\//i;
  const needsSession = (url) => SESSION_HOST_RE.test(String(url || ''));
  /** Erros do chrome.downloads que valem uma 2ª tentativa pelo fetch na sessão do site. */
  const SESSION_RETRY_ERRORS = ['SERVER_FORBIDDEN', 'SERVER_UNAUTHORIZED', 'SERVER_BAD_CONTENT', 'SERVER_FAILED', 'NETWORK_FAILED'];
  const shouldRetryWithSession = (reason) => SESSION_RETRY_ERRORS.includes(String(reason || '').toUpperCase());

  /** Nome para mídia de qualquer site: Argon/Videos/<título> [host].ext */
  function mediaFileName(title, url, kind, ext, rootFolder = 'Argon', suffix = '') {
    let host = 'site';
    try { host = new URL(url).hostname.replace(/^www\./, ''); } catch (_) { /* fica "site" */ }
    const folder = kind === 'audio' ? 'Audios' : 'Videos';
    return `${rootFolder}/${folder}/${safeName(title, 'video')}${suffix} [${safeName(host, 'site')}].${ext}`;
  }

  return {
    ALPHABET, AD_REWARD,
    checkDigit, validateKey, makeKey, maskKey,
    walletGrant, walletConsume, canDownload, ctaLabel, creditsText, dayKey, freeLeft, canUse, walletLabel, walletText,
    parseVideo, safeName, fileName,
    classifyMedia, mediaKey, parseM3U8, pickVariant, fetchAll, mediaFileName, mp4Duration, matchDuration,
    SESSION_HOST_RE, TIKTOK_HOST_RE, needsSession, shouldRetryWithSession
  };
});
