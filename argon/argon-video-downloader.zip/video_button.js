/**
 * video_button.js — Botão "⚡ Baixar" que aparece ao passar o mouse sobre qualquer vídeo (qualquer site,
 * exceto YouTube, que tem o botão próprio). Estilo isolado em Shadow DOM. Quem decide tudo é o background.
 */
(() => {
  if (window.__argonVideoBtn) return;
  window.__argonVideoBtn = true;

  const MIN_W = 220;
  const MIN_H = 120;
  let host, btn, toast, current = null, hideTimer = null, busy = false;

  function build() {
    host = document.createElement('argon-video-btn');
    host.style.cssText = 'all:initial;position:fixed;z-index:2147483646;top:0;left:0;display:none;';
    const root = host.attachShadow({ mode: 'closed' });
    root.innerHTML = `<style>
      .b{all:unset;cursor:pointer;display:inline-flex;align-items:center;gap:6px;padding:7px 13px;border-radius:999px;color:#fff;
        font:600 13px/1 Inter,"Segoe UI",system-ui,sans-serif;background:linear-gradient(90deg,#6366f1,#a855f7 55%,#06b6d4);
        box-shadow:0 4px 16px rgba(139,92,246,.55);transition:transform .12s}
      .b:hover{transform:translateY(-1px)} .b[aria-busy="true"]{opacity:.6;cursor:wait}
      .t{display:none;margin-top:6px;max-width:260px;padding:8px 10px;border-radius:10px;background:rgba(11,14,20,.94);color:#e6e9f2;
        font:12px/1.4 Inter,"Segoe UI",system-ui,sans-serif;border:1px solid rgba(255,255,255,.12)}
      .t.on{display:block}</style>
      <button class="b" type="button">⚡ Baixar</button><div class="t"></div>`;
    btn = root.querySelector('.b');
    toast = root.querySelector('.t');
    btn.addEventListener('click', onClick);
    host.addEventListener('mouseenter', () => clearTimeout(hideTimer));
    host.addEventListener('mouseleave', scheduleHide);
    (document.body || document.documentElement).appendChild(host);
  }

  function say(text) {
    toast.textContent = text;
    toast.classList.toggle('on', !!text);
  }

  function place(v) {
    const r = v.getBoundingClientRect();
    host.style.top = `${Math.max(4, r.top + 10)}px`;
    host.style.left = `${Math.max(4, r.right - 120)}px`;
  }

  function show(v) {
    if (!host) build();
    if (!host.isConnected) (document.body || document.documentElement).appendChild(host);
    current = v;
    clearTimeout(hideTimer);
    place(v);
    host.style.display = 'block';
  }

  function scheduleHide() {
    clearTimeout(hideTimer);
    hideTimer = setTimeout(() => {
      if (host && !busy) {
        host.style.display = 'none';
        say('');
      }
    }, 1500);
  }

  async function onClick(e) {
    e.preventDefault();
    e.stopPropagation();
    if (!e.isTrusted) return; // só clique de verdade da pessoa (a página não consegue disparar)
    if (busy || !current) return;
    busy = true;
    btn.setAttribute('aria-busy', 'true');
    say('Preparando...');
    let res;
    try {
      res = await chrome.runtime.sendMessage({
        type: 'DOWNLOAD_ELEMENT',
        src: current.currentSrc || current.src || '',
        title: document.title,
        protectedMedia: !!current.mediaKeys
      });
    } catch (_) {
      res = { ok: false, message: 'A extensão foi atualizada. Recarregue a página.' };
    }
    busy = false;
    btn.removeAttribute('aria-busy');
    if (!res?.ok) say(res?.message || 'Não foi possível baixar.');
    else if (res.mode === 'ad') say('Abrimos o anúncio em outra aba: após 15 s o download começa sozinho (+3 créditos).');
    else say('Download iniciado! Acompanhe pelo ícone ⚡ da extensão.');
    setTimeout(() => say(''), 6000);
  }

  document.addEventListener(
    'mouseover',
    (e) => {
      const v = e.target?.closest?.('video') || (current && e.target === current ? current : null);
      if (v) {
        const r = v.getBoundingClientRect();
        if (r.width >= MIN_W && r.height >= MIN_H) show(v);
        return;
      }
      // players colocam camadas por cima do <video>: procura um vídeo embaixo do ponteiro
      const under = document.elementsFromPoint?.(e.clientX, e.clientY)?.find((el) => el.tagName === 'VIDEO');
      if (under) {
        const r = under.getBoundingClientRect();
        if (r.width >= MIN_W && r.height >= MIN_H) return show(under);
      }
      if (current && !host?.contains(e.target)) scheduleHide();
    },
    { passive: true, capture: true }
  );
  window.addEventListener('scroll', () => current && host?.style.display === 'block' && place(current), { passive: true });
})();
