/**
 * offscreen.js — Documento invisível que baixa mídia e devolve um blob: URL (o service worker não consegue criar).
 * Recebe:
 *   { target:'offscreen', type:'BUILD', urls, mime, credentials } → { ok, blobUrl, size }   (HLS: junta as partes)
 *   { target:'offscreen', type:'FETCH', url, credentials, maxBytes } → { ok, blobUrl, size, mime }
 *       (arquivo direto pela sessão do site: cookies do usuário + Referer/Origin das regras DNR; contorna hotlinking)
 *   { target:'offscreen', type:'REVOKE', url }                     → libera a memória depois do download
 * Progresso vai por BUILD_PROGRESS ({ done, total } em partes, ou { done, total, unit:'bytes' } no FETCH).
 */
const C = self.ARGON_CORE;

const progress = (data) => chrome.runtime.sendMessage({ type: 'BUILD_PROGRESS', ...data }).catch(() => {});
const creds = (c) => (c === 'include' ? 'include' : 'omit');

async function fetchPart(url, credentials) {
  if (!/^https?:\/\//i.test(url)) throw new Error('endereço inválido');
  const res = await fetch(url, { credentials: creds(credentials), cache: 'no-store' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.arrayBuffer();
}

/** Arquivo inteiro em streaming (progresso por bytes, teto de memória) → Blob. */
async function fetchWhole(url, credentials, maxBytes) {
  if (!/^https?:\/\//i.test(url)) throw new Error('Endereço inválido.');
  const res = await fetch(url, { credentials: creds(credentials), cache: 'no-store', redirect: 'follow' });
  if (!res.ok) {
    throw new Error(res.status === 401 || res.status === 403
      ? `O site recusou o vídeo (HTTP ${res.status}). O link pode ter expirado: recarregue a página, dê play e tente de novo.`
      : `O site respondeu HTTP ${res.status}.`);
  }
  const mime = (res.headers.get('content-type') || '').split(';')[0].trim().toLowerCase();
  if (mime.startsWith('text/html')) throw new Error('O site devolveu uma página em vez do vídeo (link expirado?). Recarregue a página e tente de novo.');
  const total = Number(res.headers.get('content-length')) || 0;
  const tooBig = 'Vídeo grande demais para baixar pelo navegador.';
  if (maxBytes && total > maxBytes) throw new Error(tooBig);

  const chunks = [];
  let done = 0;
  let last = 0;
  if (!res.body) {
    chunks.push(new Uint8Array(await res.arrayBuffer()));
    done = chunks[0].byteLength;
  } else {
    const reader = res.body.getReader();
    for (;;) {
      const { done: end, value } = await reader.read();
      if (end) break;
      chunks.push(value);
      done += value.byteLength;
      if (maxBytes && done > maxBytes) {
        reader.cancel().catch(() => {});
        throw new Error(tooBig);
      }
      const now = Date.now();
      if (now - last > 300) {
        last = now;
        progress({ done, total, unit: 'bytes' });
      }
    }
  }
  if (!done) throw new Error('O site devolveu um arquivo vazio.');
  progress({ done, total: total || done, unit: 'bytes' });
  return new Blob(chunks, { type: mime || 'application/octet-stream' });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.target !== 'offscreen' || sender.id !== chrome.runtime.id) return false;

  if (msg.type === 'REVOKE') {
    try { URL.revokeObjectURL(msg.url); } catch (_) { /* já liberado */ }
    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === 'FETCH') {
    fetchWhole(msg.url, msg.credentials, Number(msg.maxBytes) || 0)
      .then((blob) => sendResponse({ ok: true, blobUrl: URL.createObjectURL(blob), size: blob.size, mime: blob.type }))
      .catch((err) => sendResponse({ ok: false, message: err?.message || String(err) }));
    return true; // resposta assíncrona
  }

  if (msg.type === 'BUILD') {
    C.fetchAll(msg.urls, (u) => fetchPart(u, msg.credentials), {
      concurrency: 6,
      retries: 2,
      onProgress: (done, total) => progress({ done, total })
    })
      .then((parts) => {
        const blob = new Blob(parts, { type: msg.mime || 'application/octet-stream' });
        sendResponse({ ok: true, blobUrl: URL.createObjectURL(blob), size: blob.size });
      })
      .catch((err) => sendResponse({ ok: false, message: err?.message || String(err) }));
    return true; // resposta assíncrona
  }
  return false;
});
