/**
 * offscreen.js — Documento invisível que baixa as partes de um stream HLS e junta num arquivo (Blob).
 * O service worker não consegue criar blob: URL; aqui dá. Recebe:
 *   { target:'offscreen', type:'BUILD', urls, mime } → { ok, blobUrl, size }  (manda BUILD_PROGRESS no caminho)
 *   { target:'offscreen', type:'REVOKE', url }       → libera a memória depois do download
 */
const C = self.ARGON_CORE;

async function fetchPart(url) {
  const res = await fetch(url, { credentials: 'include', cache: 'no-store' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.arrayBuffer();
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.target !== 'offscreen' || sender.id !== chrome.runtime.id) return false;

  if (msg.type === 'REVOKE') {
    try { URL.revokeObjectURL(msg.url); } catch (_) { /* já liberado */ }
    sendResponse({ ok: true });
    return false;
  }

  if (msg.type === 'BUILD') {
    C.fetchAll(msg.urls, fetchPart, {
      concurrency: 6,
      retries: 2,
      onProgress: (done, total) => chrome.runtime.sendMessage({ type: 'BUILD_PROGRESS', done, total }).catch(() => {})
    })
      .then((parts) => {
        const blob = new Blob(parts, { type: msg.mime || 'application/octet-stream' });
        sendResponse({ ok: true, blobUrl: URL.createObjectURL(blob), size: blob.size });
      })
      .catch((err) => sendResponse({ ok: false, message: err?.message || String(err) }));
    return true; // resposta assíncrona
  }
  return false;
});
