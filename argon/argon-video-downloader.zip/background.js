/**
 * background.js — Service worker (Manifest V3) do Argon Video Downloader.
 *
 * 1. Plano grátis (N downloads por dia) e Vitalício (chave ARGON-XXXX-XXXX-C conferida no servidor de licenças).
 * 2. Modo universal (universal.js): acha e baixa vídeos/áudios das páginas (arquivo direto e HLS sem proteção).
 * 3. Edição PRO (distribuição direta) importa também os arquivos do YouTube; a edição da loja não tem esses arquivos.
 * 4. Download: chrome.downloads para Downloads/Argon/Videos/ ou Audios/; crédito/limite só conta quando o arquivo conclui.
 */
importScripts('config.js', 'core.js', 'universal.js');

const CFG = self.ARGON_CONFIG;
const C = self.ARGON_CORE;

const K = {
  credits: 'argonCredits',
  key: 'argonKey',
  keyOk: 'argonKeyOk',        // servidor confirmou a chave (timestamp)
  device: 'argonDevice',
  daily: 'argonDaily',        // { day: 'AAAA-MM-DD', used } — downloads grátis do dia
  status: 'argonStatus',
  pending: 'argonPendingAds', // session
  jobs: 'argonJobs'           // session: downloadId -> { charged }
};

let activeJob = null;

/* ================================================================== utilitários */

const delay = (ms) => new Promise((r) => setTimeout(r, ms));

/** Fila simples: leituras-modificações da carteira nunca se cruzam. */
let lock = Promise.resolve();
function withLock(fn) {
  const run = lock.then(fn, fn);
  lock = run.catch(() => {});
  return run;
}

async function setStatus(patch) {
  const { [K.status]: cur = {} } = await chrome.storage.local.get(K.status);
  const next = { ...cur, ...patch, updatedAt: Date.now() };
  await chrome.storage.local.set({ [K.status]: next });
  return next;
}

async function getWallet() {
  const d = await chrome.storage.local.get([K.credits, K.key, K.keyOk, K.daily]);
  // Com servidor configurado, a chave só vale depois de confirmada por ele; sem servidor, só o checksum.
  const lifetime = C.validateKey(d[K.key]) && (!CFG.apiUrl || !!d[K.keyOk]);
  const perDay = Number(CFG.free?.perDay) || 0;
  return {
    credits: Number(d[K.credits]) || 0,
    lifetime,
    keyMasked: lifetime ? C.maskKey(d[K.key]) : '',
    freePerDay: perDay,
    freeLeft: C.freeLeft(d[K.daily], today(), perDay),
    adEnabled: !!CFG.ad.enabled,
    adSeconds: CFG.ad.durationSeconds
  };
}

const YT_BLOCKED_MSG = 'Por regras da Chrome Web Store, esta versão não baixa vídeos do YouTube.';

const today = () => C.dayKey(Date.now(), new Date().getTimezoneOffset());
const LIMIT_MSG = () => `Você já usou os ${CFG.free?.perDay || 0} downloads grátis de hoje. Volte amanhã ou pegue o Vitalício (R$ 15) para baixar à vontade.`;

/* ================================================================ servidor de licenças */

async function deviceId() {
  const d = await chrome.storage.local.get(K.device);
  if (d[K.device]) return d[K.device];
  const id = crypto.randomUUID();
  await chrome.storage.local.set({ [K.device]: id });
  return id;
}

/** { ok, message?, revoked?, offline? } — offline = não deu para falar com o servidor. */
async function askServer(key) {
  try {
    const res = await fetch(`${CFG.apiUrl.replace(/\/$/, '')}/ativar`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ key, device: await deviceId() })
    });
    return await res.json();
  } catch (_) {
    return { ok: false, offline: true, message: 'Sem conexão com o servidor de licenças. Tente de novo.' };
  }
}

/** Reconfere a chave de tempos em tempos: estorno revoga; falta de internet NÃO tira o Vitalício. */
async function recheckKey() {
  if (!CFG.apiUrl) return;
  const d = await chrome.storage.local.get([K.key, K.keyOk]);
  if (!d[K.key] || !d[K.keyOk]) return;
  if (Date.now() - d[K.keyOk] < CFG.recheckDays * 86400000) return;
  const r = await askServer(d[K.key]);
  if (r.ok) await chrome.storage.local.set({ [K.keyOk]: Date.now() });
  else if (!r.offline) await chrome.storage.local.remove([K.key, K.keyOk]);
}

const changeCredits = (fn) =>
  withLock(async () => {
    const { [K.credits]: c = 0 } = await chrome.storage.local.get(K.credits);
    const next = fn(Number(c) || 0);
    await chrome.storage.local.set({ [K.credits]: next });
    return next;
  });

/* ====================================================================== instalação */

chrome.runtime.onInstalled.addListener(async () => {
  const { [K.credits]: c } = await chrome.storage.local.get(K.credits);
  await chrome.storage.local.set({
    ...(c === undefined ? { [K.credits]: 0 } : {}),
    [K.status]: { state: 'idle', message: 'Pronto para baixar.', updatedAt: Date.now() }
  });
  if (typeof installMediaRule === 'function') await installMediaRule();
});
chrome.runtime.onStartup.addListener(() => {
  if (typeof installMediaRule === 'function') installMediaRule();
  recheckKey();
});

// O service worker reiniciou no meio de uma extração → avisa em vez de mentir.
chrome.storage.local.get(K.status).then(({ [K.status]: s }) => {
  if (s?.state === 'running') {
    setStatus({ state: 'error', message: 'Interrompido (o Chrome suspendeu a extensão). Clique em Baixar de novo.' });
  }
});

/* ===================================================================== mensagens */

const YT_RE = /^https:\/\/(www|m)\.youtube\.com\//;
const FROM_YOUTUBE = new Set(['GET_WALLET', 'DOWNLOAD', 'REQUEST_AD', 'GET_STATUS', 'OPEN_CHECKOUT']);
const FROM_ANY_PAGE = new Set(['GET_WALLET', 'DOWNLOAD_ELEMENT', 'OPEN_CHECKOUT']); // botão ⚡ sobre vídeos de qualquer site

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id) return false;
  const url = sender.url || '';
  const fromExtension = url.startsWith(chrome.runtime.getURL(''));
  const fromYoutube = !!sender.tab && YT_RE.test(url) && FROM_YOUTUBE.has(msg?.type);
  const fromPage = !!sender.tab && /^https?:/.test(url) && FROM_ANY_PAGE.has(msg?.type);
  const fromGateway = !!sender.tab && isGatewayUrl(url) && msg?.type === 'AD_COMPLETED_EXTERNAL';
  if (!fromExtension && !fromYoutube && !fromPage && !fromGateway) return false;

  handleMessage(msg, sender)
    .then(sendResponse)
    .catch((err) => sendResponse({ ok: false, message: err?.message || String(err) }));
  return true;
});

async function handleMessage(msg, sender) {
  switch (msg?.type) {
    case 'GET_WALLET':
      recheckKey().catch(() => {});
      return { ok: true, ...(await getWallet()) };

    case 'GET_STATUS': {
      const { [K.status]: s } = await chrome.storage.local.get(K.status);
      return { ok: true, status: s || { state: 'idle', message: 'Pronto para baixar.' } };
    }

    case 'ACTIVATE_KEY': {
      const key = String(msg.key || '').trim().toUpperCase();
      if (!C.validateKey(key)) return { ok: false, message: 'Chave inválida. Confira e tente de novo.' };
      if (CFG.apiUrl) {
        const r = await askServer(key);
        if (!r.ok) return { ok: false, message: r.message || 'Chave recusada pelo servidor.' };
        await chrome.storage.local.set({ [K.key]: key, [K.keyOk]: Date.now() });
      } else {
        await chrome.storage.local.set({ [K.key]: key });
      }
      return { ok: true, ...(await getWallet()) };
    }

    case 'CLEAR_KEY':
      await chrome.storage.local.remove([K.key, K.keyOk]);
      return { ok: true, ...(await getWallet()) };

    case 'DOWNLOAD':
      return startDownload(msg.videoId, msg.mode === 'audio' ? 'audio' : 'video');

    case 'REQUEST_AD': {
      if (msg.videoId) return openAd({ type: 'yt', videoId: msg.videoId, mode: msg.mode === 'audio' ? 'audio' : 'video' });
      if (msg.tabId != null && msg.itemId) {
        const found = await findListed(msg.tabId, msg.itemId);
        return openAd(found ? { type: 'media', ...found } : null);
      }
      return openAd(null);
    }

    case 'GET_PAGE_MEDIA':
      return listMedia(Number(msg.tabId));

    case 'DOWNLOAD_MEDIA': {
      const found = await findListed(Number(msg.tabId), msg.itemId);
      if (!found) return { ok: false, message: 'Esse vídeo saiu da lista. Abra a extensão de novo.' };
      return startJob({ type: 'media', ...found });
    }

    case 'DOWNLOAD_ELEMENT':
      return downloadElement(msg, sender);

    case 'BUILD_PROGRESS':
      return buildProgress(msg);

    case 'AD_COMPLETED_EXTERNAL':
      return completeAd(msg.nonce, sender);

    case 'OPEN_CHECKOUT':
      await chrome.tabs.create({
        url: CFG.checkoutUrl || (CFG.apiUrl ? `${CFG.apiUrl.replace(/\/$/, '')}/comprar` : chrome.runtime.getURL('vendas.html'))
      });
      return { ok: true };

    default:
      return { ok: false, message: 'Mensagem desconhecida.' };
  }
}

/* ======================================================================== anúncio */

function gatewayStatus() {
  const url = CFG.ad.gatewayUrl || '';
  if (!/^https:\/\//.test(url)) return { enabled: false };
  const matches = (chrome.runtime.getManifest().content_scripts || []).flatMap((cs) => cs.matches || []);
  const covered = matches.some((m) => url.toLowerCase().startsWith(m.replace(/\*$/, '').toLowerCase()));
  return covered ? { enabled: true, url } : { enabled: false };
}

function isGatewayUrl(url) {
  const g = gatewayStatus();
  return g.enabled && (url || '').toLowerCase().startsWith(g.url.toLowerCase());
}

async function getPending() {
  const { [K.pending]: p = {} } = await chrome.storage.session.get(K.pending);
  const now = Date.now();
  for (const [n, item] of Object.entries(p)) if (now - item.createdAt > CFG.ad.pendingTtlMs) delete p[n];
  return p;
}
const savePending = (p) => chrome.storage.session.set({ [K.pending]: p });

async function openAd(job) {
  if (!CFG.ad.enabled) return { ok: false, code: 'LIMIT', message: LIMIT_MSG() };
  const w = await getWallet();
  if (w.lifetime) return { ok: false, message: 'Você tem o plano Vitalício: não precisa de anúncio.' };
  const g = gatewayStatus();
  if (!g.enabled) return { ok: false, message: 'Gateway de anúncio não configurado (config.js × manifest.json).' };

  const nonce = crypto.randomUUID();
  let pending = await getPending();
  pending[nonce] = { createdAt: Date.now(), job, adTabId: null };
  await savePending(pending);

  const url = `${g.url}?nonce=${encodeURIComponent(nonce)}&app=${encodeURIComponent(CFG.ad.appId)}`;
  await setStatus({ state: 'waiting_ad', message: 'Assista ao anúncio para liberar +3 downloads.' });
  const tab = await chrome.tabs.create({ url, active: true });

  pending = await getPending();
  if (pending[nonce]) {
    pending[nonce].adTabId = tab.id;
    await savePending(pending);
  }
  return { ok: true, mode: 'ad' };
}

// Aba do anúncio fechada antes do fim → tira da fila.
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const pending = await getPending();
  const entry = Object.entries(pending).find(([, item]) => item.adTabId === tabId);
  if (!entry) return;
  delete pending[entry[0]];
  await savePending(pending);
  const { [K.status]: s } = await chrome.storage.local.get(K.status);
  if (s?.state === 'waiting_ad') await setStatus({ state: 'idle', message: 'Anúncio fechado antes do fim. Nenhum crédito liberado.' });
});

/** Só vale: nonce existente, vindo do ad_listener, na MESMA aba que o background abriu, após ≥ 15 s medidos aqui. */
async function completeAd(nonce, sender) {
  const pending = await getPending();
  const item = pending[nonce];
  if (!item) return { ok: false, message: 'Token de liberação inválido, expirado ou já usado.' };
  if (!isGatewayUrl(sender.url) || sender.tab?.id !== item.adTabId) return { ok: false, message: 'Origem do token inválida.' };

  const elapsed = Date.now() - item.createdAt;
  if (elapsed < CFG.ad.durationSeconds * 1000 - CFG.ad.toleranceMs) return { ok: false, message: 'Anúncio incompleto.' };

  delete pending[nonce]; // uso único
  await savePending(pending);

  const credits = await changeCredits(C.walletGrant);
  await setStatus({ state: 'idle', message: `✔ +${C.AD_REWARD} créditos liberados (total: ${credits}).` });

  if (sender.tab?.id != null) {
    setTimeout(() => chrome.tabs.remove(sender.tab.id).catch(() => {}), CFG.ad.closeGatewayAfterMs);
  }
  // Se o anúncio veio de um pedido de download, já começa (o crédito é descontado só quando concluir).
  if (item.job && !activeJob) startJob(item.job).catch(() => {});
  return { ok: true, credits };
}

/* ======================================================================= download */

const startDownload = (videoId, mode) => startJob({ type: 'yt', videoId, mode });

/** Porta única de download (YouTube ou qualquer site): confere carteira e dispara sem esperar. */
async function startJob(job) {
  if (job?.type === 'yt' && (CFG.edition === 'store' || typeof runDownload !== 'function')) {
    return { ok: false, code: 'YOUTUBE_BLOCKED', message: YT_BLOCKED_MSG };
  }
  if (job?.type === 'yt' && !/^[A-Za-z0-9_-]{11}$/.test(String(job.videoId || ''))) {
    return { ok: false, message: 'Abra um vídeo ou Short do YouTube.' };
  }
  if (job?.type !== 'yt' && !job?.item) return { ok: false, message: 'Nenhum vídeo escolhido.' };
  if (activeJob) return { ok: false, message: 'Já existe um download em preparação. Aguarde um instante.' };

  const w = await getWallet();
  if (!C.canUse(w)) {
    return w.adEnabled
      ? { ok: false, code: 'NEED_AD', message: 'Sem créditos. Veja 1 anúncio para liberar +3 downloads.' }
      : { ok: false, code: 'LIMIT', message: LIMIT_MSG() };
  }
  if (job.type === 'yt') runDownload(job.videoId, job.mode); // sem await: a interface recebe a resposta na hora
  else runMedia(job);
  return { ok: true };
}

/** Inicia o chrome.downloads e espera o servidor aceitar (bytes chegando) antes de dar como iniciado. */
async function beginFile(url, filename, { charge = true, blob = null } = {}) {
  let id;
  try {
    id = await chrome.downloads.download({
      url,
      filename,
      conflictAction: 'uniquify',
      saveAs: false
    });
  } catch (err) {
    return { ok: false, reason: err?.message || 'erro ao iniciar' };
  }
  if (id === undefined) return { ok: false, reason: chrome.runtime.lastError?.message || 'não iniciou' };

  if (charge) {
    const { [K.jobs]: jobs = {} } = await chrome.storage.session.get(K.jobs);
    jobs[id] = { charged: false, blob };
    await chrome.storage.session.set({ [K.jobs]: jobs });
  }

  const deadline = Date.now() + CFG.download.startTimeoutMs;
  while (Date.now() < deadline) {
    const [item] = await chrome.downloads.search({ id });
    if (!item) break;
    if (item.state === 'interrupted') {
      await dropJob(id);
      return { ok: false, reason: item.error || 'interrompido' };
    }
    if (item.state === 'complete') {
      await settle(id); // arquivo pequeno: pode ter terminado antes do job existir
      return { ok: true, id, done: true };
    }
    if (item.bytesReceived > 0) return { ok: true, id };
    await delay(300);
  }
  return { ok: true, id }; // ainda conectando: o Chrome segue sozinho; onChanged cobra o crédito ao terminar
}

async function dropJob(id) {
  const { [K.jobs]: jobs = {} } = await chrome.storage.session.get(K.jobs);
  delete jobs[id];
  await chrome.storage.session.set({ [K.jobs]: jobs });
}

/** Download concluído = −1 crédito (uma vez só por arquivo; Vitalício não gasta). */
const jobLock = (fn) => withLock(fn); // mesma fila da carteira: cobrança nunca duplica

/** Cobra 1 crédito (se concluído e ainda não cobrado) ou registra a interrupção. Idempotente. */
function settle(id) {
  return jobLock(async () => {
    const { [K.jobs]: jobs = {} } = await chrome.storage.session.get(K.jobs);
    const job = jobs[id];
    if (!job) return;
    const [item] = await chrome.downloads.search({ id });
    if (job.blob && item?.state !== 'in_progress') revokeBlob(job.blob);
    if (item?.state === 'complete' && !job.charged) {
      job.charged = true;
      await chrome.storage.session.set({ [K.jobs]: jobs });
      const w = await getWallet();
      let msg = '✔ Download concluído (Vitalício ∞).';
      if (!w.lifetime && w.freeLeft > 0) {
        // gasta primeiro o grátis do dia
        const day = today();
        const { [K.daily]: dly } = await chrome.storage.local.get(K.daily);
        const used = dly?.day === day ? (Number(dly.used) || 0) + 1 : 1;
        await chrome.storage.local.set({ [K.daily]: { day, used } });
        const left = Math.max(0, w.freePerDay - used);
        msg = left ? `✔ Download concluído. Restam ${left} grátis hoje.` : '✔ Download concluído. Acabaram os grátis de hoje: volta amanhã ou Vitalício (R$ 15).';
      } else if (!w.lifetime) {
        const credits = C.walletConsume(w.credits);
        await chrome.storage.local.set({ [K.credits]: credits });
        msg = `✔ Download concluído. Restam ${credits} crédito(s).`;
      }
      await setStatus({ state: 'done', message: msg });
    } else if (item?.state === 'interrupted') {
      delete jobs[id];
      await chrome.storage.session.set({ [K.jobs]: jobs });
      await setStatus({ state: 'error', message: `Download interrompido (${item.error || 'erro'}). Nenhum crédito foi gasto.` });
    }
  });
}

chrome.downloads.onChanged.addListener((delta) => {
  if (delta.state) settle(delta.id);
});
