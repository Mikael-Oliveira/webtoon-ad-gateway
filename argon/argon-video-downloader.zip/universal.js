/**
 * universal.js — Modo universal do Argon (importado pelo background.js).
 * Qualquer site: (1) "fareja" as respostas de mídia da aba (webRequest, só observa),
 * (2) varre <video>/<audio>/og:video de todos os frames, (3) baixa:
 *   - arquivo direto (mp4/webm/mp3…) → chrome.downloads com o Referer da página; CDN com hotlinking
 *     (TikTok/Instagram/Facebook/X) ou servidor que recusa (403) → fetch na sessão (Offscreen) → Blob → chrome.downloads;
 *   - HLS (.m3u8) sem criptografia → baixa as partes no Offscreen Document e junta num arquivo (.ts ou .mp4).
 * NÃO contorna DRM nem criptografia (Netflix, Prime, Disney+, HLS com EXT-X-KEY): avisa e para.
 * Usa do background.js: C, CFG, setStatus, beginFile, startJob, openAd, revokeBlob, activeJob.
 */
const RULE_REF_XHR = 13;
const RULE_REF_FILE = 14;
const RULE_SESSION_CDN = 15; // TikTok: Referer/Origin fixos em toda busca da extensão (fica sempre ligada)
const MAX_SESSION_BYTES = 1536 * 1024 * 1024; // fetch na sessão guarda o vídeo na memória: teto de 1,5 GB
const MAX_PER_TAB = 60;
const MIN_VIDEO_BYTES = 150 * 1024; // menor que isso costuma ser prévia/anúncio
const MSG = {
  PROTECTED: 'Este vídeo é protegido (DRM ou criptografia). A Argon não baixa conteúdo protegido.',
  LIVE: 'É uma transmissão ao vivo: só dá para baixar depois que ela terminar.',
  DASH: 'Este site usa DASH (vídeo e áudio separados), que ainda não é suportado.',
  BYTERANGE: 'Formato de stream não suportado (HLS por intervalos de bytes).',
  NONE: 'Não achei vídeo baixável nesta página. Dê play no vídeo e tente de novo.'
};

const tabMedia = new Map(); // tabId -> Map(mediaKey -> item)

/** Edição da loja: nada do YouTube (nem farejar, nem listar, nem baixar). */
const YT_PAGE = /^https?:\/\/([a-z0-9-]+\.)*(youtube\.com|youtu\.be|youtube-nocookie\.com)(\/|$)/i;
const isStore = () => CFG.edition === 'store';
const blockedYouTube = (url) => isStore() && YT_PAGE.test(url || '');
let persistTimer = null;

const header = (hs, name) => (hs || []).find((h) => h.name.toLowerCase() === name)?.value || '';

async function loadTabMedia(tabId) {
  if (tabMedia.has(tabId)) return tabMedia.get(tabId);
  const { argonMedia = {} } = await chrome.storage.session.get('argonMedia');
  const m = new Map((argonMedia[tabId] || []).map((it) => [C.mediaKey(it.url), it]));
  tabMedia.set(tabId, m);
  return m;
}

function persistMedia() {
  clearTimeout(persistTimer);
  persistTimer = setTimeout(() => {
    const obj = {};
    for (const [tabId, m] of tabMedia) obj[tabId] = [...m.values()].slice(-MAX_PER_TAB);
    chrome.storage.session.set({ argonMedia: obj }).catch(() => {});
  }, 500);
}

/** Chamado pelo webRequest (e pelos testes): registra uma resposta de mídia vista na aba. */
async function recordResponse(d) {
  if (d.tabId < 0 || d.statusCode >= 400) return;
  if (blockedYouTube(d.initiator) || blockedYouTube(d.documentUrl)) return;
  const info = C.classifyMedia(d.url, header(d.responseHeaders, 'content-type'));
  if (!info) return;
  const len = Number(header(d.responseHeaders, 'content-length')) || 0;
  const total = Number((/\/(\d+)\s*$/.exec(header(d.responseHeaders, 'content-range')) || [])[1]) || 0;
  const m = await loadTabMedia(d.tabId);
  const key = C.mediaKey(d.url);
  const prev = m.get(key);
  m.set(key, {
    url: prev?.url || d.url,
    kind: info.kind,
    ext: info.ext,
    size: Math.max(prev?.size || 0, total || len),
    referer: d.initiator && d.initiator !== 'null' ? d.initiator + '/' : '',
    seen: prev?.seen || Date.now()
  });
  if (m.size > MAX_PER_TAB) m.delete(m.keys().next().value);
  persistMedia();
}

chrome.webRequest.onHeadersReceived.addListener(
  (d) => { recordResponse(d); },
  { urls: ['<all_urls>'], types: ['media', 'xmlhttprequest', 'other', 'object'] },
  ['responseHeaders']
);

chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.url) {
    tabMedia.set(tabId, new Map()); // página nova: lista nova
    persistMedia();
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  tabMedia.delete(tabId);
  persistMedia();
});

/** Roda DENTRO da página (cada frame): acha vídeos/áudios e sinais de DRM. Precisa ser autocontida. */
function scanPage() {
  const items = [];
  const screens = []; // vídeos tocados via blob: (MSE) — sem URL, só duração
  let protectedMedia = false;
  let blob = false;
  const add = (url, kind, extra = {}) => {
    if (url && /^https?:/i.test(url)) items.push({ url, kind, ...extra });
    else if (url && url.startsWith('blob:')) {
      blob = true;
      if (kind === 'video' && extra.seconds) screens.push({ duration: extra.duration, playing: extra.playing, area: extra.area });
    }
  };
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  document.querySelectorAll('video, audio').forEach((v) => {
    if (v.mediaKeys) protectedMedia = true;
    const kind = v.tagName === 'AUDIO' ? 'audio' : 'video';
    const r = v.getBoundingClientRect();
    // área visível na tela: o vídeo que a pessoa está vendo é o maior e/ou o que está tocando
    const area = Math.max(0, Math.min(r.right, vw) - Math.max(r.left, 0)) * Math.max(0, Math.min(r.bottom, vh) - Math.max(r.top, 0));
    const playing = !v.paused && !v.ended && v.currentTime > 0;
    const duration = Number.isFinite(v.duration) ? v.duration : 0;
    add(v.currentSrc || v.src, kind, { h: v.videoHeight || 0, area, playing, duration, seconds: Math.round(duration) });
    v.querySelectorAll('source[src]').forEach((s) => add(s.src, kind, { area, playing }));
  });
  document
    .querySelectorAll('meta[property="og:video"], meta[property="og:video:url"], meta[property="og:video:secure_url"]')
    .forEach((m) => add(m.content, 'video', { og: true }));
  return { items, screens, protectedMedia, blob, title: document.title, url: location.href, top: window === window.top };
}

/** Só endereços http(s) públicos: nada de localhost, rede local ou IP privado (a página não escolhe alvos internos). */
function isPublicUrl(raw) {
  let u;
  try { u = new URL(raw); } catch (_) { return false; }
  if (!/^https?:$/.test(u.protocol)) return false;
  const h = u.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (h === 'localhost' || h.endsWith('.localhost') || h.endsWith('.local') || h.endsWith('.internal')) return false;
  if (/^(127\.|10\.|0\.|169\.254\.|192\.168\.)/.test(h) || /^172\.(1[6-9]|2\d|3[01])\./.test(h)) return false;
  if (h === '::1' || /^f[cd][0-9a-f]{2}:/.test(h) || /^fe80:/.test(h)) return false;
  return true;
}

/** Cookies só quando o arquivo é do mesmo site da página (ex.: www.site.com → cdn.site.com). */
function sameSite(url, pageUrl) {
  try {
    const a = new URL(url).hostname.split('.').slice(-2).join('.');
    const b = new URL(pageUrl).hostname.split('.').slice(-2).join('.');
    return a === b;
  } catch (_) {
    return false;
  }
}
const credFor = (url, pageUrl) => (sameSite(url, pageUrl) ? 'include' : 'omit');
const originOf = (u) => { try { return new URL(u).origin + '/'; } catch (_) { return ''; } };
const MAX_PARTS = 6000;

async function fetchText(url, pageUrl) {
  if (!isPublicUrl(url)) throw new Error('Endereço de vídeo bloqueado (rede local).');
  const res = await fetch(url, { credentials: credFor(url, pageUrl), cache: 'no-store' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.text();
}

/** Referer (e Origin nas buscas da extensão) da página dona do vídeo, só nos domínios do vídeo. */
let refererGen = 0; // cada troca de regra ganha um número: a limpeza atrasada não apaga a regra de outro download
async function setRefererRule(urls, referer) {
  refererGen++;
  const domains = [...new Set(urls.filter(Boolean).map((u) => {
    try { return new URL(u).hostname; } catch (_) { return null; }
  }).filter(Boolean))];
  const removeRuleIds = [RULE_REF_XHR, RULE_REF_FILE];
  if (!domains.length || !/^https?:/.test(referer || '')) {
    await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds });
    return;
  }
  const origin = new URL(referer).origin;
  const cond = (types) => ({ requestDomains: domains, tabIds: [chrome.tabs.TAB_ID_NONE], resourceTypes: types });
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds,
    addRules: [
      {
        id: RULE_REF_XHR,
        priority: 2,
        action: {
          type: 'modifyHeaders',
          requestHeaders: [
            { header: 'referer', operation: 'set', value: referer },
            { header: 'origin', operation: 'set', value: origin }
          ]
        },
        condition: cond(['xmlhttprequest'])
      },
      {
        id: RULE_REF_FILE,
        priority: 2,
        action: { type: 'modifyHeaders', requestHeaders: [{ header: 'referer', operation: 'set', value: referer }] },
        condition: cond(['media', 'other'])
      }
    ]
  });
}

/** Tira as regras de Referer/Origin depois de `ms`, a menos que outro download tenha trocado a regra nesse meio-tempo. */
function clearRefererRuleLater(ms = 15000) {
  const gen = refererGen;
  setTimeout(() => {
    if (gen === refererGen) setRefererRule([], '').catch(() => {});
  }, ms);
}

/**
 * TikTok (v16-webapp-prime.tiktok.com, *.tiktokcdn.com…): o CDN devolve 403 sem Referer/Origin do tiktok.com.
 * Regra de sessão sempre ligada, só para buscas da própria extensão (tabId -1) e nunca para as do próprio
 * TikTok (excludedInitiatorDomains), com prioridade acima da regra genérica. Origin sem barra no fim (padrão HTTP).
 */
async function installSessionCdnRule() {
  await chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [RULE_SESSION_CDN],
    addRules: [{
      id: RULE_SESSION_CDN,
      priority: 3,
      action: {
        type: 'modifyHeaders',
        requestHeaders: [
          { header: 'referer', operation: 'set', value: 'https://www.tiktok.com/' },
          { header: 'origin', operation: 'set', value: 'https://www.tiktok.com' }
        ]
      },
      condition: {
        regexFilter: C.TIKTOK_HOST_RE.source, // RE2 aceita; casa qualquer host que contenha "tiktok"
        isUrlFilterCaseSensitive: false,
        tabIds: [chrome.tabs.TAB_ID_NONE],
        excludedInitiatorDomains: ['tiktok.com'],
        resourceTypes: ['xmlhttprequest', 'media', 'other']
      }
    }]
  });
}
// regra de sessão some quando o Chrome fecha: reinstala a cada partida do service worker (idempotente).
// Em microtarefa: este arquivo roda dentro do importScripts, antes do `const C` do background.js existir.
Promise.resolve().then(installSessionCdnRule).catch(() => {});

const fmtSize = (b) => (b >= 1048576 ? `${(b / 1048576).toFixed(1).replace('.', ',')} MB` : b >= 1024 ? `${Math.round(b / 1024)} KB` : '');
const hostOf = (u) => {
  try { return new URL(u).hostname.replace(/^www\./, ''); } catch (_) { return ''; }
};
const lists = new Map(); // tabId -> { title, items }
const durations = new Map(); // mediaKey -> segundos (cache)

/** Duração de um MP4 remoto lendo só o começo do arquivo (Range). null se não der. */
async function durationOf(url) {
  const key = C.mediaKey(url);
  if (durations.has(key)) return durations.get(key);
  let d = null;
  try {
    if (!isPublicUrl(url)) return null;
    const res = await fetch(url, { headers: { range: 'bytes=0-131071' }, credentials: C.needsSession(url) ? 'include' : 'omit', cache: 'no-store' });
    if (res.ok) d = C.mp4Duration(new Uint8Array(await res.arrayBuffer()));
  } catch (_) { /* sem duração: fica de fora do casamento */ }
  durations.set(key, d);
  return d;
}

/** Junta varredura da página + respostas farejadas, entende os HLS e devolve a lista para o popup. */
async function listMedia(tabId) {
  let tab;
  try { tab = await chrome.tabs.get(tabId); } catch (_) { return { ok: false, message: 'Aba não encontrada.' }; }
  if (!/^https?:/.test(tab.url || '')) return { ok: true, title: tab.title, items: [], note: 'Abra um site para procurar vídeos.' };
  if (blockedYouTube(tab.url)) return { ok: true, title: tab.title, items: [], blocked: 'youtube', note: YT_BLOCKED_MSG };

  let frames = [];
  try {
    frames = (await chrome.scripting.executeScript({ target: { tabId, allFrames: true }, func: scanPage }))
      .map((r) => r.result)
      .filter(Boolean);
  } catch (_) { /* página que o Chrome não deixa ler: fica só o que foi farejado */ }

  const title = frames.find((f) => f.top)?.title || tab.title || 'video';
  const protectedPage = frames.some((f) => f.protectedMedia);
  const map = new Map();
  for (const f of frames) {
    for (const it of f.items) {
      const c = C.classifyMedia(it.url, it.kind === 'audio' ? 'audio/unknown' : 'video/unknown');
      if (!c) continue;
      // o mesmo arquivo pode estar em vários <video> (ex.: um tocando e uma cópia pausada): junta, sem perder o que toca
      const key = C.mediaKey(it.url);
      const prev = map.get(key);
      const area = (f.top ? 1 : 0.9) * (it.area || 0);
      map.set(key, {
        url: it.url, kind: c.kind, ext: c.ext, size: 0, referer: originOf(f.url), pageUrl: f.url,
        height: Math.max(prev?.height || 0, it.h || 0),
        area: Math.max(prev?.area || 0, area),
        playing: !!prev?.playing || !!it.playing,
        seconds: prev?.seconds || it.seconds || 0,
        onPage: true
      });
    }
  }
  // "Este vídeo": o que está tocando; se nenhum estiver, o mais visível na tela.
  const onPage = [...map.values()].filter((it) => it.kind !== 'audio' || it.playing);
  const current = onPage.filter((it) => it.playing).sort((a, b) => b.area - a.area)[0]
    || onPage.filter((it) => it.area > 0).sort((a, b) => b.area - a.area)[0];
  if (current) current.current = true;
  for (const [key, it] of await loadTabMedia(tabId)) {
    const prev = map.get(key);
    map.set(key, { ...it, ...(prev || {}), size: Math.max(prev?.size || 0, it.size || 0), referer: prev?.referer || originOf(tab.url), pageUrl: prev?.pageUrl || tab.url });
  }

  // Player com blob: (TikTok, Instagram, X…): o vídeo da tela não tem URL. Lê a duração dos MP4 farejados
  // (primeiros 128 KB, box 'mvhd') e marca como "da tela" o que tem a mesma duração do vídeo tocando/visível.
  const screens = frames.flatMap((f) => f.screens || []);
  const screen = screens.filter((s) => s.playing).sort((a, b) => b.area - a.area)[0]
    || screens.filter((s) => s.area > 0).sort((a, b) => b.area - a.area)[0];
  const fileVideos = [...map.values()].filter((it) => it.kind === 'video' && (!it.size || it.size >= MIN_VIDEO_BYTES)).slice(-12);
  // o vídeo blob vence o vídeo com URL quando está tocando e ele não, ou quando ocupa mais a tela
  const screenWins = screen && (!current || (screen.playing && !current.playing) || screen.area > (current.area || 0));
  if (fileVideos.length && screenWins) {
    await setRefererRule(fileVideos.map((it) => it.url), originOf(tab.url)).catch(() => {});
    await Promise.all(fileVideos.map(async (it) => {
      if (!it.seconds) it.seconds = Math.round((await durationOf(it.url)) || 0);
      it.duration = durations.get(C.mediaKey(it.url)) || 0;
    }));
    const hit = C.matchDuration(screen.duration, fileVideos);
    if (hit) {
      if (current) current.current = false;
      hit.current = true;
    }
  }

  // HLS: lê as playlists para separar master × variante, achar a resolução e marcar criptografia/ao vivo.
  const hls = [...map.entries()].filter(([, it]) => it.kind === 'hls').slice(0, 8);
  if (hls.length) await setRefererRule(hls.map(([, it]) => it.url), originOf(tab.url)).catch(() => {});
  const children = new Set();
  await Promise.all(hls.map(async ([key, it]) => {
    try {
      const p = C.parseM3U8(await fetchText(it.url, tab.url), it.url);
      if (!p) { map.delete(key); return; }
      if (p.type === 'master') {
        p.variants.forEach((v) => children.add(C.mediaKey(v.url)));
        p.media.forEach((m) => m.url && children.add(C.mediaKey(m.url)));
        it.height = Math.max(0, ...p.variants.map((v) => v.height));
      } else {
        it.protected = p.encrypted;
        it.live = !p.ended;
        it.seconds = Math.round(p.duration || 0);
      }
    } catch (_) { /* fica na lista; o erro aparece se tentar baixar */ }
  }));
  for (const k of children) map.delete(k);

  const items = [...map.values()]
    .filter((it) => isPublicUrl(it.url))
    .filter((it) => !(it.kind === 'video' && it.size && it.size < MIN_VIDEO_BYTES))
    // ordem: vídeo da tela › vídeos que estão na página › streams com qualidade conhecida › maior resolução › maior arquivo
    .sort((a, b) => !!b.current - !!a.current || !!b.onPage - !!a.onPage
      || ((b.kind === 'hls' && b.height) ? 1 : 0) - ((a.kind === 'hls' && a.height) ? 1 : 0)
      || (b.height || 0) - (a.height || 0) || (b.size || 0) - (a.size || 0))
    .slice(0, 25)
    .map((it, i) => ({
      ...it,
      id: `m${i + 1}`,
      protected: !!it.protected,
      current: !!it.current,
      label: [
        it.kind === 'hls' ? 'Stream HLS' : it.kind === 'dash' ? 'Stream DASH' : it.ext.toUpperCase(),
        it.height ? `${it.height}p` : '',
        it.seconds ? `${Math.floor(it.seconds / 60)}:${String(it.seconds % 60).padStart(2, '0')}` : '',
        it.kind === 'hls' || it.kind === 'dash' ? '' : fmtSize(it.size), // em stream o tamanho é o da playlist
        it.live ? 'ao vivo' : '',
        it.protected ? '🔒 protegido' : ''
      ].filter(Boolean).join(' · '),
      host: hostOf(it.url)
    }));

  lists.set(tabId, { title, items });
  await chrome.storage.session.set({ [`argonList:${tabId}`]: { title, items } }).catch(() => {});
  let note = '';
  if (!items.length) {
    note = protectedPage ? MSG.PROTECTED
      : frames.some((f) => f.blob) ? 'O vídeo ainda não foi identificado: dê play e abra a extensão de novo.'
      : MSG.NONE;
  }
  return { ok: true, title, items: items.map(({ id, kind, label, host, current }) => ({ id, kind, label, host, current })), protectedPage, note };
}

async function findListed(tabId, itemId) {
  let l = lists.get(tabId);
  if (!l) l = (await chrome.storage.session.get(`argonList:${tabId}`))[`argonList:${tabId}`];
  const item = l?.items.find((it) => it.id === itemId);
  return item ? { item, title: l.title } : null;
}

/** Botão ⚡ sobre um <video> de qualquer site. Sem créditos → abre o anúncio já com o pedido. */
async function downloadElement(msg, sender) {
  const tabId = sender.tab.id;
  if (blockedYouTube(sender.url) || blockedYouTube(sender.tab.url)) return { ok: false, code: 'YOUTUBE_BLOCKED', message: YT_BLOCKED_MSG };
  if (msg.protectedMedia) return { ok: false, message: MSG.PROTECTED };
  let job;
  const direct = /^https?:/i.test(msg.src || '') ? C.classifyMedia(msg.src, 'video/unknown') : null;
  if (direct) {
    if (!isPublicUrl(msg.src)) return { ok: false, message: 'Endereço de vídeo bloqueado (rede local).' };
    job = { type: 'media', title: msg.title || sender.tab.title, item: { url: msg.src, kind: direct.kind, ext: direct.ext, referer: originOf(sender.url), pageUrl: sender.url } };
  } else {
    const r = await listMedia(tabId);
    const first = r.items?.find((it) => it.current && it.kind !== 'dash') || r.items?.find((it) => it.kind !== 'dash');
    if (!first) return { ok: false, message: r.note || MSG.NONE };
    job = { type: 'media', ...(await findListed(tabId, first.id)) };
  }
  const res = await startJob(job);
  if (res.code === 'NEED_AD' && CFG.ad.enabled) return openAd(job);
  return res;
}

/* ---------------------------------------------------------------- execução */

async function finishStart(started, title, file) {
  if (started.ok && started.done) return;
  if (!started.ok) {
    await setStatus({ state: 'error', message: `O site recusou o download (${started.reason}). Nenhum crédito foi gasto.` });
    return;
  }
  const [cur] = await chrome.downloads.search({ id: started.id });
  if (cur?.state === 'complete') return;
  await setStatus({
    state: 'downloading',
    message: `Baixando "${title}"...`,
    downloadId: started.id,
    progress: null,
    folder: `Downloads/${file.replace(/\/[^/]*$/, '')}`
  });
}

async function runMedia({ item, title }) {
  activeJob = { url: item.url };
  const root = CFG.download.rootFolder;
  try {
    if (item.protected) throw new Error(MSG.PROTECTED);
    if (item.live) throw new Error(MSG.LIVE);
    if (item.kind === 'dash') throw new Error(MSG.DASH);
    if (!isPublicUrl(item.url)) throw new Error('Endereço de vídeo bloqueado (rede local).');
    await setStatus({ state: 'running', message: `Preparando "${title}"...`, downloadId: null, progress: null, folder: '' });
    await setRefererRule([item.url], item.referer);

    if (item.kind === 'hls') {
      await runHls(item, title);
      return;
    }
    const filename = C.mediaFileName(title, item.url, item.kind, item.ext, root);
    await finishStart(await downloadDirect(item, title, filename), title, filename);
  } catch (err) {
    await setStatus({ state: 'error', message: err?.message || String(err), progress: null });
  } finally {
    activeJob = null;
    // o download já começou com os cabeçalhos certos: tira as regras de Referer/Origin
    clearRefererRuleLater();
  }
}

/**
 * Arquivo direto (MP4/WebM/MP3…).
 * - CDN com hotlinking (TikTok, Instagram, Facebook, X): nem tenta o chrome.downloads; vai direto pela sessão.
 * - Outros: chrome.downloads (grava direto no disco, sem RAM). Se o servidor recusar (403/401…), 2ª tentativa
 *   pela sessão. Falha na 1ª tentativa não gasta crédito (beginFile já descarta o job).
 */
async function downloadDirect(item, title, filename) {
  if (!C.needsSession(item.url)) {
    const started = await beginFile(item.url, filename);
    if (started.ok || !C.shouldRetryWithSession(started.reason)) return started;
  }
  return downloadViaSession(item, title, filename);
}

/**
 * fetch() do arquivo no Offscreen Document (cookies do usuário + Referer/Origin pelas regras DNR) → Blob →
 * blob: URL → chrome.downloads com o nome final. O blob é liberado em settle() quando o download termina.
 */
async function downloadViaSession(item, title, filename) {
  await setStatus({ state: 'running', message: `Baixando "${title}" pela sessão do site...`, progress: null });
  const r = await offscreenFetch(item.url, `Baixando "${title}":`);
  const started = await beginFile(r.blobUrl, filename, { blob: r.blobUrl });
  if (!started.ok) revokeBlob(r.blobUrl); // download nem começou: libera a memória na hora
  return started;
}

async function loadMediaPlaylist(url, pageUrl) {
  const p = C.parseM3U8(await fetchText(url, pageUrl), url);
  if (!p || p.type !== 'media') throw new Error('Playlist de vídeo inválida.');
  if (p.encrypted) throw new Error(MSG.PROTECTED);
  if (p.byterange) throw new Error(MSG.BYTERANGE);
  if (!p.ended) throw new Error(MSG.LIVE);
  if (!p.segments.length) throw new Error('A playlist veio vazia.');
  if (p.segments.length > MAX_PARTS) throw new Error('Vídeo grande demais para baixar pelo navegador.');
  if (![p.init, ...p.segments].filter(Boolean).every(isPublicUrl)) throw new Error('Endereço de vídeo bloqueado (rede local).');
  return p;
}

async function runHls(item, title) {
  const root = CFG.download.rootFolder;
  const pageUrl = item.pageUrl || item.referer;
  let p = C.parseM3U8(await fetchText(item.url, pageUrl), item.url);
  if (!p) throw new Error('Playlist HLS inválida.');
  let audio = null;
  if (p.type === 'master') {
    const pick = C.pickVariant(p);
    if (!pick) throw new Error('A playlist HLS não tem qualidades.');
    await setRefererRule([pick.variant.url, pick.audio?.url], item.referer);
    const video = await loadMediaPlaylist(pick.variant.url, pageUrl);
    if (pick.audio) audio = await loadMediaPlaylist(pick.audio.url, pageUrl);
    p = video;
  } else {
    p = await loadMediaPlaylist(item.url, pageUrl);
  }

  const parts = [p.init, ...p.segments].filter(Boolean);
  const aParts = audio ? [audio.init, ...audio.segments].filter(Boolean) : [];
  await setRefererRule([...parts, ...aParts], item.referer);

  const cookies = C.needsSession(parts[0]) ? 'include' : credFor(parts[0], pageUrl);
  const v = await offscreenBuild(parts, p.ext === 'mp4' ? 'video/mp4' : 'video/mp2t', `Baixando "${title}":`, cookies);
  const filename = C.mediaFileName(title, item.url, 'video', p.ext, root);
  const started = await beginFile(v.blobUrl, filename, { blob: v.blobUrl });

  if (audio) {
    const a = await offscreenBuild(aParts, audio.ext === 'mp4' ? 'audio/mp4' : 'video/mp2t', 'Baixando o áudio:', cookies);
    const aName = C.mediaFileName(title, item.url, 'video', audio.ext === 'mp4' ? 'm4a' : 'ts', root, ' (audio)');
    await beginFile(a.blobUrl, aName, { charge: false });
    setTimeout(() => revokeBlob(a.blobUrl), 10 * 60 * 1000);
  }
  await finishStart(started, title, filename);
  if (audio && started.ok) {
    await setStatus({ message: `Baixando "${title}"... (o áudio deste site vem em arquivo separado: "(audio)")` });
  }
}

/* ------------------------------------------------- Offscreen Document (junta as partes) */

let progressAt = 0;
let progressLabel = '';

async function ensureOffscreen() {
  const ctx = await chrome.runtime.getContexts?.({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
  if (ctx?.length) return;
  try {
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['BLOBS'],
      justification: 'Baixar vídeos pela sessão do site (CDNs com proteção de hotlinking) e juntar partes de streams HLS num único arquivo para download.'
    });
  } catch (err) {
    if (!/single offscreen|already/i.test(err?.message || '')) throw err;
  }
}

async function offscreenBuild(urls, mime, label, credentials = 'omit') {
  await ensureOffscreen();
  progressLabel = label;
  const r = await chrome.runtime.sendMessage({ target: 'offscreen', type: 'BUILD', urls, mime, credentials });
  if (!r?.ok) throw new Error(r?.message || 'Não consegui juntar as partes do vídeo.');
  return r;
}

/** Um arquivo inteiro pela sessão do site (Offscreen) → { ok, blobUrl, size, mime }. */
async function offscreenFetch(url, label) {
  await ensureOffscreen();
  progressLabel = label;
  const r = await chrome.runtime.sendMessage({ target: 'offscreen', type: 'FETCH', url, credentials: 'include', maxBytes: MAX_SESSION_BYTES });
  if (!r?.ok) throw new Error(`${r?.message || 'Não consegui baixar o vídeo pela sessão do site.'} Nenhum crédito foi gasto.`);
  return r;
}

async function buildProgress({ done, total, unit }) {
  const now = Date.now();
  if (done !== total && now - progressAt < 400) return { ok: true };
  progressAt = now;
  if (unit === 'bytes') {
    const msg = total ? `${progressLabel} ${Math.round((done / total) * 100)}% (${fmtSize(done) || '0 KB'} de ${fmtSize(total)})` : `${progressLabel} ${fmtSize(done) || '0 KB'}`;
    await setStatus({ state: 'running', message: msg, progress: total ? { done, total } : null });
    return { ok: true };
  }
  await setStatus({ state: 'running', message: `${progressLabel} parte ${done}/${total}`, progress: { done, total } });
  return { ok: true };
}

function revokeBlob(url) {
  Promise.resolve(chrome.runtime.sendMessage({ target: 'offscreen', type: 'REVOKE', url })).catch(() => {});
}
